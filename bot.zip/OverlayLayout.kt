package com.example.aimassist

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

class OverlayLayout(context: Context) : View(context) {

    private val paint = Paint().apply {
        color = Color.RED
        style = Paint.Style.STROKE
        strokeWidth = 5f
    }

    private val boxes = listOf(
        android.graphics.Rect(200, 300, 400, 600), // مثال على مربع 1
        android.graphics.Rect(500, 700, 700, 900)  // مثال على مربع 2
    )

    override fun onDraw(canvas: Canvas?) {
        super.onDraw(canvas)
        canvas ?: return
        for (box in boxes) {
            canvas.drawRect(box, paint)
        }
    }

    // في التطبيق الحقيقي، ستقوم بتحديث list boxes تبع نتائج كشف العدو
}
